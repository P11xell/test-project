function Bird() {
  this.y = height/2;
  this.x = 64;

  this.gravity = -0.6;
  this.lift = -10;
  this.velocity = 0;
  
  this.show = function() {
      fill(255);
      //ellipse(this.x, this.y, 32, 32);
      image(img, this.x, this.y, 34, 24);
      
  }
  
  this.up = function() {
    //if (this.velocity < -15)
    this.velocity += this.lift;
       
    
  }
  
  this.update = function() {
    this.velocity += this.gravity;
    this.velocity += 1;
    
    
    if (this.velocity > 7)
      this.velocity = 7    
    
    if (this.velocity < -10)
      this.velocity = -10                 
    
    this.y += this.velocity;
    
    
    if (this.y > height - 32 - 55) {
      this.y = height - 32 - 55;
      this.velocity = 0;
    }
    
    if (this.y < 0) {
      this.y = 0;
      this.velocity = 0;
    }
    
  }
}
