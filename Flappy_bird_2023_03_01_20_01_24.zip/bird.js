let pfp;
let img;
let pta;
let fnd;
let caq;
function preload() {
 pfp = loadImage("cano.svg")
 img = loadImage("Easy.png")
 pta = loadImage("tampaCanotampaCano.svg") 
 fnd = loadImage("fundogrupo.svg") 
 cha = loadImage("chao.svg")
 Gao = loadImage("GameOver.png")
 bta = loadImage("Botao.png")
 btp = loadImage("BotaoApertado.png")
 caq = loadImage("canoTampa.svg")
}
var bird;
var pipes = [];



function setup() {
  createCanvas(400, 600);
  bird = new Bird();
  pipes.push(new Pipe());
  
  noLoop();
  
  button = createButton('Start')
    button.size(100, 50);
    button.position(150, 300)
    button.mouseClicked(
      function(){
        bird = new Bird();
        pipes=[];
        button.hide();
        loop()
      }
    );
}



function Reiniciar() {
  
}

function draw() {
  let button;
  function botao() {
    image(bta, 143, 193, 115, 65)
    //mouseOver(image(btp, 143, 193, 115, 65))
    button = createButton('Restart')
    button.size(100, 50);
    button.position(150, 200)
    button.mouseClicked(
      function(){
        bird = new Bird();
        pipes=[];
        button.hide();
        loop()
      }
    );
  }
  
  
  background(fnd);
  image(cha, 0, 545, 400, 150)
    for (var i = pipes.length - 1; i >= 0; i--) {
    pipes[i].show();
    pipes[i].update();
    if (pipes[i].hits(bird)) {
      console.log("HIT")
      noLoop()
      image(Gao, 25, 100, 340, 100)
      botao();
    }
      
    if(pipes[i].offscreen()) {
      pipes.splice(i, 1);
    }
  }
  bird.update();
  bird.show();
  
  if (frameCount % 100 == 0) {
    pipes.push(new Pipe());
  }
  
}



function keyPressed() {
  if (key == ' ') {
    bird.up();
    console.log('Space')
  }
  
}